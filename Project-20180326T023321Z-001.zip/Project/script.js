
	function textChange(){
	d = new Date();
	hour = d.getHours();
	min = d.getMinutes();

	document.write(hour, min);

	if(hour == 6 && min <= 29) {
  		document.getElementById("warnText").innerHTML = "Abertura do Dia.";
  		//document.write("Abertura do Dia.");
	}
	
	if(hour == 6 && min >= 30) {
  		document.getElementById("warnText").innerHTML = "Abertura do STR.";
  		//document.write("Abertura do STR.");
	}
	
	if(hour >= 6 && min >= 35) {
		document.getElementById("warnText").innerHTML = "Abertura do PAG.";
  		//document.write("Abertura do ");
	}
	
	if(hour <= 8 && min <= 30) {
		document.getElementById("warnText").innerHTML = "Pagamento CIP-SILOC noturna.";
  		//document.write("Pagamento CIP-SILOC noturna.");
	}
	 
	if(hour == 8 && min >= 30) {
		document.getElementById("warnText").innerHTML = "Pagamento COMPE noturna.";
  		//document.write("Pagamento COMPE noturna.");
	}
	 
	if(hour == 9 && min >= 00) {
		document.getElementById("warnText").innerHTML = "Pagamento GNRE Santa Catarina.";
  		//document.write("Pagamento GNRE Santa Catarina.");
	}
	 
	if(hour == 10 && min >= 00) {
		document.getElementById("warnText").innerHTML = "Pagemento FENASEG.";
  		//document.write("Pagemento FENASEG.");
	}
	 
	if(hour == 11 && min >= 00) {
		document.getElementById("warnText").innerHTML = "Pagamento BMF-Bovespa.";
  		//document.write("Pagamento BMF-Bovespa.");
	}
	 
	if(hour == 12 && min >= 30) {
  		document.getElementById("warnText").innerHTML = "Pagamento VLB-Cheques.";
  		//document.write("Pagamento VLB-Cheques.");
	}
	 
	if(hour == 12 && min >= 44) {
		document.getElementById("warnText").innerHTML = "Resultado Liquido CETIP.";
  		//document.write("Resultado Liquido CETIP.");
	}
	 
	if(hour == 14 && min >= 00) {
		document.getElementById("warnText").innerHTML = "Pagamento SIMPLES Nacional.";
  		//document.write("Pagamento SIMPLES Nacional.");
	}
	 
	if(hour == 15 && min >= 50) {
		document.getElementById("warnText").innerHTML = "Pagamento CIP-SILOC diurna.";
  		//document.write("Pagamento CIP-SILOC diurna.");
	}
	 
	if(hour == 16 && min >= 00) {
		document.getElementById("warnText").innerHTML = "Pagamentos BACEN (multas, compulsório).";
  		//document.write("Pagamentos BACEN (multas, compulsório).");
	}
	 
	if(hour == 16 && min >= 30) {
		document.getElementById("warnText").innerHTML = "Encerramento Canais Banrisul.";
  		//document.write("Encerramento Canais Banrisul.");
	}
	 
	if(hour == 16 && min >= 50) {
		document.getElementById("warnText").innerHTML = "Pagamento COMPE diurna.";
  		//document.write("Pagamento COMPE diurna.");
	}
	
	// >=>=>==    REVER   >=>=>== 
	if(hour == 17 && min <= 30) {
		document.getElementById("warnText").innerHTML = "Fechamento da PAG.<br/>" + "Liquidação Leilões.<br/>" + "Pagamento Redesconto.";
  		//document.write("Fechamento da PAG.</br>");
  		//document.write("Liquidação Leilões.<br/>");
  		//document.write("Pagamento Redesconto.");
	}
	 
	if(hour == 17 && min >= 30) {
		document.getElementById("warnText").innerHTML = "Fim da grade do STR.";
  		//document.write("Fim da grade do STR.");
	}
	 
	if(hour == 18 && min >= 00) {
		document.getElementById("warnText").innerHTML = "Ajuste do compulsório.";
  		//document.write("Ajuste do compulsório.");
	}
	 
	if(hour == 18 && min >= 30) {
		document.getElementById("warnText").innerHTML = "Fechamento do STR.";
  		//document.write("Fechamento do STR.");
	}
	
	if(hour == 19 && min >= 00) {
		document.getElementById("warnText").innerHTML = "Fechamento do Dia.";
  		//document.write("Fechamento do Dia.");
	} else {
		document.getElementById("warnText").innerHTML = "Olá! Expediente finalizado.<br/>Aguarde até a próxima chamada!";
	}
 }

function watch() {
	data = new Date();
	hora = data.getHours();
	minuto = data.getMinutes();

	document.write(hora + ":" + minuto);
}
